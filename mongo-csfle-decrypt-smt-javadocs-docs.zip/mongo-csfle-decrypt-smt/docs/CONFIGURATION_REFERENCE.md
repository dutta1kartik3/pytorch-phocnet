# Configuration Reference

This document describes only the custom decrypt SMT settings. It does not repeat the full Debezium MongoDB connector configuration.

## Required settings

### transforms.decryptMessageValue.type

```yaml
transforms.decryptMessageValue.type: "com.yourcompany.kafka.connect.csfle.MongoCsfleDecryptMessageValue"
```

Fully qualified Java class name of the custom SMT.

### transforms.decryptMessageValue.predicate

```yaml
transforms.decryptMessageValue.predicate: "isOutboxTopic"
```

Limits the SMT to the raw Debezium outbox topic. Use the same predicate as the outbox SMT.

### transforms.decryptMessageValue.after.field

```yaml
transforms.decryptMessageValue.after.field: "after"
```

Name of the Debezium MongoDB envelope field that contains the full MongoDB document JSON.

### transforms.decryptMessageValue.encrypted.field

```yaml
transforms.decryptMessageValue.encrypted.field: "messageValue"
```

Name of the top-level outbox document field that contains the CSFLE ciphertext.

### transforms.decryptMessageValue.mongodb.connection.string

```yaml
transforms.decryptMessageValue.mongodb.connection.string: "$MONGODB_CONNECTION_STRING"
```

MongoDB connection string used by MongoDB `ClientEncryption` to access the key vault collection.

This can be the same MongoDB deployment used by Debezium, but it must have the permissions required to read the key vault collection.

### transforms.decryptMessageValue.key.vault.namespace

```yaml
transforms.decryptMessageValue.key.vault.namespace: "encryption.__keyVault"
```

MongoDB namespace of the key vault collection used by the application that encrypted the field.

The decrypt SMT must use the same key vault namespace as the writer application.

### transforms.decryptMessageValue.kms.provider

```yaml
transforms.decryptMessageValue.kms.provider: "local"
```

Supported values:

```text
local
aws
azure
gcp
kmip
```

Provider-specific required fields are described below.

## Local KMS settings

```yaml
transforms.decryptMessageValue.kms.provider: "local"
transforms.decryptMessageValue.kms.local.master.key.base64: "$CSFLE_LOCAL_MASTER_KEY_BASE64"
```

The local master key must be the same 96-byte key used by the application that encrypted the field, base64 encoded for convenient secret injection.

## AWS KMS settings

```yaml
transforms.decryptMessageValue.kms.provider: "aws"
transforms.decryptMessageValue.kms.aws.access.key.id: "$AWS_ACCESS_KEY_ID"
transforms.decryptMessageValue.kms.aws.secret.access.key: "$AWS_SECRET_ACCESS_KEY"
transforms.decryptMessageValue.kms.aws.session.token: "$AWS_SESSION_TOKEN"
```

`kms.aws.session.token` is optional and is only needed for temporary STS credentials.

## Azure Key Vault settings

```yaml
transforms.decryptMessageValue.kms.provider: "azure"
transforms.decryptMessageValue.kms.azure.tenant.id: "$AZURE_TENANT_ID"
transforms.decryptMessageValue.kms.azure.client.id: "$AZURE_CLIENT_ID"
transforms.decryptMessageValue.kms.azure.client.secret: "$AZURE_CLIENT_SECRET"
transforms.decryptMessageValue.kms.azure.identity.platform.endpoint: "$AZURE_IDENTITY_PLATFORM_ENDPOINT"
```

`kms.azure.identity.platform.endpoint` is optional.

## GCP KMS settings

```yaml
transforms.decryptMessageValue.kms.provider: "gcp"
transforms.decryptMessageValue.kms.gcp.email: "$GCP_SERVICE_ACCOUNT_EMAIL"
transforms.decryptMessageValue.kms.gcp.private.key: "$GCP_SERVICE_ACCOUNT_PRIVATE_KEY"
transforms.decryptMessageValue.kms.gcp.endpoint: "$GCP_KMS_ENDPOINT"
```

`kms.gcp.endpoint` is optional.

## KMIP settings

```yaml
transforms.decryptMessageValue.kms.provider: "kmip"
transforms.decryptMessageValue.kms.kmip.endpoint: "kmip.example.com:5696"
```

## Behavior settings

### missing.field.behavior

```yaml
transforms.decryptMessageValue.missing.field.behavior: "fail"
```

Supported values:

```text
fail
ignore
```

`fail` is recommended for outbox reliability. `ignore` returns the record unchanged if `messageValue` is absent.

### null.field.behavior

```yaml
transforms.decryptMessageValue.null.field.behavior: "fail"
```

Supported values:

```text
fail
ignore
```

`fail` is recommended for outbox reliability. `ignore` returns the record unchanged if `messageValue` is explicitly null.

### decrypted.value.mode

```yaml
transforms.decryptMessageValue.decrypted.value.mode: "string"
```

Supported values:

```text
string
preserve_bson
```

Use `string` for your current outbox setup. In this mode, if the decrypted value is a BSON string, its string content is written back into `messageValue`. If the decrypted value is another BSON type, it is serialized to relaxed JSON text and then written as a string.

Use `preserve_bson` only if a downstream transform expects the payload field to remain a structured BSON/JSON value instead of a string.

## Recommended config block

```yaml
transforms: "decryptMessageValue,outbox,routeHeartbeat"

transforms.decryptMessageValue.type: "com.yourcompany.kafka.connect.csfle.MongoCsfleDecryptMessageValue"
transforms.decryptMessageValue.predicate: "isOutboxTopic"
transforms.decryptMessageValue.after.field: "after"
transforms.decryptMessageValue.encrypted.field: "messageValue"
transforms.decryptMessageValue.mongodb.connection.string: "$MONGODB_CONNECTION_STRING"
transforms.decryptMessageValue.key.vault.namespace: "encryption.__keyVault"
transforms.decryptMessageValue.kms.provider: "local"
transforms.decryptMessageValue.kms.local.master.key.base64: "$CSFLE_LOCAL_MASTER_KEY_BASE64"
transforms.decryptMessageValue.missing.field.behavior: "fail"
transforms.decryptMessageValue.null.field.behavior: "fail"
transforms.decryptMessageValue.decrypted.value.mode: "string"
```
