# Custom SMT Design

## Problem being solved

The MongoDB outbox document has a `messageValue` field encrypted with MongoDB CSFLE before the document is inserted into `msgv2_outbox`. Debezium can capture the insert, but Debezium does not automatically decrypt CSFLE ciphertext. The Debezium MongoDB outbox SMT expects the payload field to already contain the value that should be written to Kafka.

This custom SMT bridges that gap:

```text
Raw Debezium event has encrypted messageValue
  -> custom SMT decrypts messageValue
  -> Debezium outbox SMT publishes the decrypted value
```

## What a Kafka Connect SMT is

An SMT is a small piece of code that Kafka Connect runs on each record before the record is written to Kafka by a source connector or before a record is delivered to a sink connector. For a Debezium source connector, the order is:

```text
Debezium reads source database change
  -> Debezium creates a SourceRecord in memory
  -> Kafka Connect applies configured SMTs in order
  -> Kafka Connect converts/serializes the transformed record
  -> Kafka producer writes the record to Kafka
```

A transform receives one record and returns either the original record or a new record. For this project, returning a new record is important because Kafka Connect transformations should avoid mutating objects reachable from the original record.

## Why this SMT runs before the outbox SMT

The Debezium MongoDB outbox SMT reads the configured payload field, in your case `messageValue`, and turns it into the Kafka value. If `messageValue` is still encrypted when the outbox SMT runs, the outbox SMT will publish ciphertext.

Therefore the transform order must be:

```text
1. decryptMessageValue
2. outbox
3. routeHeartbeat
```

The decrypt SMT changes only the raw Debezium `after` JSON. It does not choose the final Kafka topic. The outbox SMT still performs the final routing based on `topicName`.

## Input record shape

Debezium MongoDB emits records whose value contains an `after` field for create events. That `after` field is a JSON string containing the MongoDB document.

A simplified raw record value looks like:

```json
{
  "after": "{\"_id\":\"evt-123\",\"topicName\":\"events.orders\",\"messageKey\":\"order-456\",\"messageValue\":{\"$binary\":{\"base64\":\"...\",\"subType\":\"06\"}}}",
  "op": "c"
}
```

The encrypted field appears in Extended JSON as BSON Binary subtype `06`, which is the MongoDB CSFLE encrypted value subtype.

## Output record shape after the decrypt SMT

After this custom SMT runs, the raw Debezium record still has an `after` field, but the `messageValue` field inside that JSON is plaintext:

```json
{
  "after": "{\"_id\":\"evt-123\",\"topicName\":\"events.orders\",\"messageKey\":\"order-456\",\"messageValue\":\"{\\\"orderId\\\":\\\"order-456\\\"}\"}",
  "op": "c"
}
```

Then Debezium's MongoDB outbox SMT reads:

```text
topicName    -> final Kafka topic
messageKey   -> Kafka key
messageValue -> Kafka value
```

## Class responsibilities

### MongoCsfleDecryptMessageValue

This is the Kafka Connect SMT entry point. Kafka Connect loads this class from the plugin path and calls:

```text
configure(props)
apply(record)
close()
config()
```

Its job is orchestration only. It parses config, constructs dependencies, reads the `after` field, calls the decryptor, and returns a new record when the payload changes.

### CsfleDecryptConfig

This class owns all configuration parsing and validation. It defines the Kafka Connect `ConfigDef`, parses enum-style settings, and validates KMS-provider-specific required fields.

### DebeziumMongoRecordAccessor

Debezium values can be schemaful `Struct` objects or schemaless `Map` objects. This class reads and replaces the configured `after` field for both forms. It always copies the original value object rather than mutating it.

### MongoCsfleFieldDecryptor

This class performs the core transformation on the MongoDB document JSON:

```text
parse after JSON
  -> locate encrypted field
  -> extract BSON binary subtype 6
  -> decrypt
  -> format decrypted value
  -> write field back
  -> return updated JSON
```

### EncryptedBinaryExtractor

This class converts the parsed Extended JSON field into a `BsonBinary` and validates that the subtype is `6`. This protects the decryptor from receiving the wrong type of BSON binary.

### DecryptedValueFormatter

This class decides how to write the decrypted BSON value back into the document. The default `string` mode is intended for your outbox pattern, where `messageValue` should be JSON text that the Debezium outbox SMT later expands.

### BsonDecryptor

This is a small interface that hides the production MongoDB `ClientEncryption` dependency. It makes the code unit-testable because tests can inject a fake decryptor.

### ClientEncryptionBsonDecryptor

This is the production implementation of `BsonDecryptor`. It delegates to MongoDB Java driver's `ClientEncryption.decrypt(...)`.

### ClientEncryptionFactory

This class constructs MongoDB `ClientEncryption` from the configured MongoDB connection string, key vault namespace, and KMS provider settings.

## Why the design is split into several classes

The split follows a simple separation of concerns:

```text
Kafka Connect lifecycle       -> MongoCsfleDecryptMessageValue
Config parsing/validation     -> CsfleDecryptConfig
Record shape handling         -> DebeziumMongoRecordAccessor
BSON ciphertext extraction    -> EncryptedBinaryExtractor
CSFLE decryption              -> BsonDecryptor / ClientEncryptionBsonDecryptor
Plaintext formatting          -> DecryptedValueFormatter
JSON document rewrite         -> MongoCsfleFieldDecryptor
```

This makes it easier to unit test each behavior without spinning up Kafka Connect, MongoDB, or KMS.

## Failure behavior

The SMT intentionally fails fast for unsafe conditions by throwing Kafka Connect `ConnectException` or config exceptions:

- invalid config
- missing encrypted field when configured to `fail`
- null encrypted field when configured to `fail`
- encrypted field is not BSON Binary subtype 6
- MongoDB CSFLE decryption fails
- unsupported Debezium record value type

For an outbox connector, fail-fast behavior is usually preferable to silently dropping or publishing malformed business events.

## Predicate behavior

The SMT should be configured with the same `isOutboxTopic` predicate used by the Debezium outbox SMT. That ensures it only runs for the raw Debezium topic representing `msgv2_outbox`, not for heartbeat records.

Without the predicate, the SMT would see heartbeat records, which do not have a MongoDB `after` document, and would either skip them or fail depending on record shape. Predicate-based isolation is cleaner.
