# Security and Operations Notes

## Plaintext boundary

Before this SMT runs, `messageValue` is ciphertext in MongoDB and in Debezium's raw SourceRecord. After this SMT runs, plaintext exists inside Kafka Connect and then in Kafka.

Treat the following as plaintext-sensitive:

```text
Kafka Connect worker memory
Kafka Connect logs
Kafka producer buffers
Kafka output topic
Kafka broker storage
Consumer applications
Monitoring systems that capture record payloads
```

## Logging risk

If the connector has:

```yaml
errors.log.include.messages: "true"
```

then failed records can include keys, values, and headers in logs. Once the decrypt SMT has run, those logs may contain plaintext payloads. This is useful during initial validation but should be reviewed before long-term production use.

## Recommended error tolerance

Do not set:

```yaml
errors.tolerance: "all"
```

for this connector unless the business explicitly accepts losing outbox events. If the SMT cannot decrypt an event, failing the connector is usually safer than silently skipping the record.

## Secrets

Do not hardcode KMS credentials or local master keys in plain Helm values files. Prefer Kubernetes Secrets, external secret managers, or your platform's standard secret injection mechanism.

The local KMS master key must be the exact same 96-byte key used by the application that encrypted the field.

## Required permissions

The Kafka Connect worker needs:

```text
1. Read access to the MongoDB key vault collection.
2. KMS decrypt permissions for the customer master key.
3. Network access to MongoDB key vault.
4. Network access to the KMS provider, unless using local KMS.
5. Kafka write access to every dynamic topic named in topicName.
6. Kafka write access to the heartbeat topic.
```

## Availability considerations

This SMT makes MongoDB key-vault and KMS availability part of the Kafka Connect source connector's availability. If key vault or KMS is unavailable, the connector can fail or pause on decryption errors.

That is usually acceptable when every outbox event must be published correctly, but it should be reflected in alerting and runbooks.

## Payload size

The decrypted plaintext payload still needs to fit Kafka producer, broker, and topic message-size limits. Validate payload size before inserting the outbox document, especially if encryption can hide large payload growth.

## Monitoring suggestions

Monitor at least:

```text
Kafka Connect connector/task status
Kafka Connect task error logs
Output topic message rate
Heartbeat topic message rate
MongoDB key-vault access errors
KMS decrypt errors
Producer errors for unknown topic or authorization failures
```

## Rollback plan

If the SMT causes issues, a safe rollback usually means:

```text
1. Pause the connector.
2. Remove decryptMessageValue from transforms.
3. Remove transforms.decryptMessageValue.* configs.
4. Resume/restart the connector only if downstream can handle encrypted payloads.
```

If downstream cannot handle encrypted payloads, do not simply remove the SMT. Instead, fix the SMT/KMS issue and replay or resume from the correct Debezium offset according to your data-loss tolerance.
