# Testing and Deployment Guide

## Local unit tests

Run:

```bash
mvn clean test
```

The unit tests do not connect to MongoDB or KMS. They inject a fake `BsonDecryptor` and verify transformation behavior around:

- config parsing
- schemaful Debezium `Struct` records
- schemaless Debezium `Map` records
- CSFLE Extended JSON subtype validation
- missing encrypted fields
- preserve-BSON mode
- immutability of original records

## Package the plugin

Run:

```bash
mvn clean test package
```

The Maven Shade plugin creates the deployable JAR:

```text
target/mongo-csfle-decrypt-smt-1.0.0.jar
```

Kafka Connect APIs are marked as `provided` and are not shaded into the plugin, because the Connect worker already provides them. MongoDB driver dependencies are included in the shaded JAR.

## Install on Kafka Connect workers

Copy the JAR to every worker:

```bash
mkdir -p /usr/local/share/kafka/plugins/mongo-csfle-decrypt-smt
cp target/mongo-csfle-decrypt-smt-1.0.0.jar \
  /usr/local/share/kafka/plugins/mongo-csfle-decrypt-smt/
```

Ensure this directory is under the worker's `plugin.path`. Restart all Kafka Connect workers so the plugin is discovered.

## Verify plugin discovery

After restart, query Kafka Connect plugin discovery:

```bash
curl -s "$CONNECT_URL/connector-plugins" | jq '.[] | select(.class | contains("MongoCsfleDecryptMessageValue"))'
```

If it does not appear:

1. Confirm the JAR is on every worker.
2. Confirm the worker `plugin.path` includes the parent plugin directory.
3. Confirm the ServiceLoader file exists inside the JAR.
4. Restart workers again if the JAR was copied after worker startup.

## Integration test checklist

Create a test output topic that definitely exists:

```text
debug.decrypted.outbox
```

Insert a fresh outbox document after the connector task is running:

```javascript
db.getSiblingDB("def-device").msgv2_outbox.insertOne({
  _id: "decrypt-test-1",
  topicName: "debug.decrypted.outbox",
  messageKey: "debug-key-1",
  messageValue: encryptedValueProducedByYourApplication,
  traceparent: "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
  "__TypeId__": "com.example.DebugEvent"
})
```

Then verify:

```text
1. The connector task remains RUNNING.
2. No raw record is written to abganerovo.def-device.msgv2_outbox.
3. The final record appears in debug.decrypted.outbox.
4. Kafka key equals debug-key-1.
5. Kafka value is plaintext JSON.
6. Headers include traceparent and __TypeId__.
7. Heartbeats still go to msgv2-outbox-heartbeat.
```

## Debugging common failures

### Plugin class not found

The class is not on the plugin path, the ServiceLoader file is missing, or workers were not restarted.

### Missing encrypted field

The document does not contain `messageValue`, or the field name in config does not match the document.

### Expected subtype 6 but found subtype X

The configured field is not a MongoDB CSFLE encrypted field, or the application wrote the ciphertext in a different shape than expected.

### MongoDB CSFLE decryption failed

Common causes:

- wrong key vault namespace
- Connect worker lacks read permissions to the key vault collection
- wrong local master key or KMS credentials
- KMS network access failure
- the data key referenced by the ciphertext is missing

### Outbox topic receives escaped JSON

Check that the decrypted value is a BSON string containing JSON text and that the outbox SMT still has:

```yaml
transforms.outbox.collection.expand.json.payload: "true"
value.converter: "org.apache.kafka.connect.storage.StringConverter"
```
