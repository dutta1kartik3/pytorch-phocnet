# Mongo CSFLE Decrypt SMT

This project contains a Kafka Connect Single Message Transform (SMT) for Debezium MongoDB source records. It decrypts one MongoDB Client-Side Field Level Encryption (CSFLE) field inside Debezium's MongoDB `after` document before Debezium's MongoDB outbox SMT routes the event to the final Kafka topic.

The intended use case is an insert-only MongoDB outbox collection where the outbox document contains an encrypted `messageValue` field. The custom SMT decrypts `messageValue`, then the Debezium `MongoEventRouter` publishes the decrypted payload to the topic named in `topicName`.

## Transform order

The decrypt SMT must run before the Debezium outbox SMT:

```yaml
transforms: "decryptMessageValue,outbox,routeHeartbeat"
```

The high-level flow is:

```text
MongoDB outbox insert
  -> Debezium creates raw SourceRecord with value.after
  -> decryptMessageValue SMT decrypts messageValue inside after JSON
  -> MongoEventRouter reads topicName/messageKey/messageValue
  -> Kafka receives plaintext payload on the final dynamic topic
```

## Build

```bash
mvn clean test package
```

The shaded plugin JAR is created under:

```text
target/mongo-csfle-decrypt-smt-1.0.0.jar
```

## Install

Copy the shaded JAR to every Kafka Connect worker under a directory that is included in the worker `plugin.path`, then restart the workers.

```bash
mkdir -p /usr/local/share/kafka/plugins/mongo-csfle-decrypt-smt
cp target/mongo-csfle-decrypt-smt-1.0.0.jar \
  /usr/local/share/kafka/plugins/mongo-csfle-decrypt-smt/
```

## Main class

```text
com.yourcompany.kafka.connect.csfle.MongoCsfleDecryptMessageValue
```

The ServiceLoader file is included at:

```text
src/main/resources/META-INF/services/org.apache.kafka.connect.transforms.Transformation
```

## Important documentation

- [Custom SMT design](docs/CUSTOM_SMT_DESIGN.md)
- [Configuration reference](docs/CONFIGURATION_REFERENCE.md)
- [Testing and deployment guide](docs/TESTING_AND_DEPLOYMENT.md)
- [Security and operations notes](docs/SECURITY_AND_OPERATIONS.md)

## Security note

After this SMT runs, Kafka Connect handles plaintext. The Connect worker heap, producer buffers, Kafka output topic, broker logs/segments, and consumers should be treated as plaintext-sensitive systems.

If `errors.log.include.messages=true`, failed records may include plaintext in Connect logs after decryption. This is useful while validating the connector but should be reviewed carefully for production.
