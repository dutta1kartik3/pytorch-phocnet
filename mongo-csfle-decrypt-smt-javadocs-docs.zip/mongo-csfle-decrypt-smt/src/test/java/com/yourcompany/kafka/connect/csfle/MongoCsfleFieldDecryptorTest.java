package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.errors.ConnectException;
import org.bson.BsonDocument;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for decrypting and rewriting the encrypted field inside Debezium's {@code after} JSON.
 */
class MongoCsfleFieldDecryptorTest {

    /**
     * Verifies canonical Extended JSON binary ciphertext becomes a decrypted JSON string payload.
     */
    @Test
    void decryptsCanonicalExtendedJsonBinaryIntoJsonStringPayload() {
        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor("{\"hello\":\"world\"}");
        MongoCsfleFieldDecryptor decryptor = newDecryptor(TestSupport.baseConfig(), fakeDecryptor);

        String decryptedAfter = decryptor.decryptFieldInAfterJson(TestSupport.afterJsonWithEncryptedMessageValue());

        BsonDocument document = BsonDocument.parse(decryptedAfter);
        assertEquals("{\"hello\":\"world\"}", document.getString("messageValue").getValue());
        assertEquals("topic-a", document.getString("topicName").getValue());
        assertEquals(1, fakeDecryptor.decryptCalls());
        assertEquals(6, Byte.toUnsignedInt(fakeDecryptor.lastEncryptedValue().getType()));
    }

    /**
     * Verifies decrypted BSON documents are serialized to JSON text when string mode is active.
     */
    @Test
    void serializesDecryptedBsonDocumentAsJsonStringInStringMode() {
        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor(BsonDocument.parse("{\"nested\": {\"x\": 1}}"));
        MongoCsfleFieldDecryptor decryptor = newDecryptor(TestSupport.baseConfig(), fakeDecryptor);

        String decryptedAfter = decryptor.decryptFieldInAfterJson(TestSupport.afterJsonWithEncryptedMessageValue());

        BsonDocument document = BsonDocument.parse(decryptedAfter);
        assertEquals("{\"nested\":{\"x\":1}}", document.getString("messageValue").getValue().replace(" ", ""));
    }

    /**
     * Verifies preserve-BSON mode writes decrypted BSON back without converting it to a string.
     */
    @Test
    void preservesDecryptedBsonWhenConfigured() {
        Map<String, String> config = TestSupport.baseConfig();
        config.put(CsfleDecryptConfig.DECRYPTED_VALUE_MODE, "preserve_bson");

        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor(BsonDocument.parse("{\"nested\": {\"x\": 1}}"));
        MongoCsfleFieldDecryptor decryptor = newDecryptor(config, fakeDecryptor);

        String decryptedAfter = decryptor.decryptFieldInAfterJson(TestSupport.afterJsonWithEncryptedMessageValue());

        BsonDocument document = BsonDocument.parse(decryptedAfter);
        assertTrue(document.get("messageValue").isDocument());
        assertEquals(1, document.getDocument("messageValue").getDocument("nested").getInt32("x").getValue());
    }

    /**
     * Verifies missing encrypted fields fail by default.
     */
    @Test
    void failsWhenEncryptedFieldIsMissingByDefault() {
        MongoCsfleFieldDecryptor decryptor = newDecryptor(TestSupport.baseConfig(), new TestSupport.FakeDecryptor("{}"));

        ConnectException exception = assertThrows(
                ConnectException.class,
                () -> decryptor.decryptFieldInAfterJson("{\"_id\":\"evt-1\"}")
        );

        assertTrue(exception.getMessage().contains("missing"));
    }

    /**
     * Verifies missing encrypted fields can be ignored when explicitly configured.
     */
    @Test
    void ignoresMissingEncryptedFieldWhenConfigured() {
        Map<String, String> config = TestSupport.baseConfig();
        config.put(CsfleDecryptConfig.MISSING_FIELD_BEHAVIOR, "ignore");

        String afterJson = "{\"_id\":\"evt-1\"}";
        MongoCsfleFieldDecryptor decryptor = newDecryptor(config, new TestSupport.FakeDecryptor("{}"));

        assertEquals(afterJson, decryptor.decryptFieldInAfterJson(afterJson));
    }

    /**
     * Verifies non-CSFLE BSON binary subtypes are rejected.
     */
    @Test
    void failsWhenEncryptedSubtypeIsNotCsfleSubtypeSix() {
        MongoCsfleFieldDecryptor decryptor = newDecryptor(TestSupport.baseConfig(), new TestSupport.FakeDecryptor("{}"));
        String afterJson = """
                {"messageValue": {"$binary": {"base64": "%s", "subType": "00"}}}
                """.formatted(TestSupport.ENCRYPTED_BASE64);

        ConnectException exception = assertThrows(
                ConnectException.class,
                () -> decryptor.decryptFieldInAfterJson(afterJson)
        );

        assertTrue(exception.getMessage().contains("subtype 6"));
    }

    /**
     * Creates a field decryptor for a test case.
     *
     * @param props SMT properties for the test
     * @param bsonDecryptor fake decryptor that returns deterministic plaintext
     * @return configured field decryptor
     */
    private MongoCsfleFieldDecryptor newDecryptor(Map<String, String> props, BsonDecryptor bsonDecryptor) {
        CsfleDecryptConfig config = CsfleDecryptConfig.from(props);
        return new MongoCsfleFieldDecryptor(
                config,
                bsonDecryptor,
                new EncryptedBinaryExtractor(),
                new DecryptedValueFormatter()
        );
    }
}
