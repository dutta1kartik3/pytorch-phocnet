package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.source.SourceRecord;
import org.bson.BsonDocument;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for the top-level Kafka Connect SMT class.
 */
class MongoCsfleDecryptMessageValueTest {

    /**
     * Verifies the SMT transforms schemaful Debezium MongoDB records.
     */
    @Test
    void transformsStructDebeziumRecord() {
        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor("{\"orderId\":\"order-456\",\"status\":\"PAID\"}");
        MongoCsfleDecryptMessageValue<SourceRecord> transformation = new MongoCsfleDecryptMessageValue<>(fakeDecryptor);
        transformation.configure(TestSupport.baseConfig());

        SourceRecord original = TestSupport.structRecord(TestSupport.afterJsonWithEncryptedMessageValue());
        SourceRecord transformed = transformation.apply(original);

        assertNotSame(original, transformed);
        assertEquals(original.topic(), transformed.topic());
        assertEquals(1, fakeDecryptor.decryptCalls());

        String transformedAfter = ((Struct) transformed.value()).getString("after");
        BsonDocument document = BsonDocument.parse(transformedAfter);
        assertEquals("{\"orderId\":\"order-456\",\"status\":\"PAID\"}", document.getString("messageValue").getValue());

        String originalAfter = ((Struct) original.value()).getString("after");
        assertTrue(originalAfter.contains("$binary"), "original record must not be mutated");
    }

    /**
     * Verifies the SMT transforms schemaless Debezium MongoDB records.
     */
    @Test
    void transformsSchemalessMapDebeziumRecord() {
        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor("{\"hello\":\"world\"}");
        MongoCsfleDecryptMessageValue<SourceRecord> transformation = new MongoCsfleDecryptMessageValue<>(fakeDecryptor);
        transformation.configure(TestSupport.baseConfig());

        SourceRecord original = TestSupport.mapRecord(TestSupport.afterJsonWithEncryptedMessageValue());
        SourceRecord transformed = transformation.apply(original);

        @SuppressWarnings("unchecked")
        Map<String, Object> transformedValue = (Map<String, Object>) transformed.value();
        BsonDocument document = BsonDocument.parse((String) transformedValue.get("after"));
        assertEquals("{\"hello\":\"world\"}", document.getString("messageValue").getValue());

        @SuppressWarnings("unchecked")
        Map<String, Object> originalValue = (Map<String, Object>) original.value();
        assertTrue(((String) originalValue.get("after")).contains("$binary"), "original map must not be mutated");
    }

    /**
     * Verifies heartbeat-like records without an {@code after} field are ignored by the SMT.
     */
    @Test
    void leavesRecordsWithoutAfterUnchanged() {
        TestSupport.FakeDecryptor fakeDecryptor = new TestSupport.FakeDecryptor("{}");
        MongoCsfleDecryptMessageValue<SourceRecord> transformation = new MongoCsfleDecryptMessageValue<>(fakeDecryptor);
        transformation.configure(TestSupport.baseConfig());

        SourceRecord record = new SourceRecord(
                Map.of("server", "abganerovo"),
                Map.of("resumeToken", "token-1"),
                "__debezium-heartbeat.abganerovo",
                null,
                null,
                null,
                null,
                Map.of("ts_ms", 123L)
        );

        SourceRecord transformed = transformation.apply(record);

        assertSame(record, transformed);
        assertEquals(0, fakeDecryptor.decryptCalls());
    }
}
