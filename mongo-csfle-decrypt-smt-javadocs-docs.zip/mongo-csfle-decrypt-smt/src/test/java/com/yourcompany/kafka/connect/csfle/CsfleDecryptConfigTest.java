package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.common.config.ConfigException;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Unit tests for {@link CsfleDecryptConfig} parsing and validation.
 */
class CsfleDecryptConfigTest {

    /**
     * Verifies the default production-style configuration is parsed into expected values.
     */
    @Test
    void parsesDefaultProductionMode() {
        CsfleDecryptConfig config = CsfleDecryptConfig.from(TestSupport.baseConfig());

        assertEquals("after", config.afterField());
        assertEquals("messageValue", config.encryptedField());
        assertEquals("local", config.kmsProvider());
        assertEquals(CsfleDecryptConfig.MissingFieldBehavior.FAIL, config.missingFieldBehavior());
        assertEquals(CsfleDecryptConfig.NullFieldBehavior.FAIL, config.nullFieldBehavior());
        assertEquals(CsfleDecryptConfig.DecryptedValueMode.STRING, config.decryptedValueMode());
    }

    /**
     * Verifies local KMS configuration fails fast when the local master key is absent.
     */
    @Test
    void requiresLocalMasterKeyWhenUsingLocalKms() {
        Map<String, String> props = TestSupport.baseConfig();
        props.remove(CsfleDecryptConfig.KMS_LOCAL_MASTER_KEY_BASE64);

        assertThrows(ConfigException.class, () -> CsfleDecryptConfig.from(props));
    }

    /**
     * Verifies unsupported KMS provider names are rejected during configuration.
     */
    @Test
    void rejectsUnknownKmsProvider() {
        Map<String, String> props = TestSupport.baseConfig();
        props.put(CsfleDecryptConfig.KMS_PROVIDER, "unknown");

        assertThrows(ConfigException.class, () -> CsfleDecryptConfig.from(props));
    }
}
