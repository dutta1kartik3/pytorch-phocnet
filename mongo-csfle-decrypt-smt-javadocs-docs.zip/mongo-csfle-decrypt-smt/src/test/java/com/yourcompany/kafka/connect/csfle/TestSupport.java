package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.SchemaBuilder;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.source.SourceRecord;
import org.bson.BsonBinary;
import org.bson.BsonString;
import org.bson.BsonValue;

import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Shared test fixtures for SMT unit tests.
 */
final class TestSupport {
    static final byte[] ENCRYPTED_BYTES = new byte[]{1, 2, 3, 4, 5};
    static final String ENCRYPTED_BASE64 = Base64.getEncoder().encodeToString(ENCRYPTED_BYTES);

    /**
     * Prevents construction of the test utility class.
     */
    private TestSupport() {
    }

    /**
     * Builds a minimal valid transform configuration for tests.
     *
     * @return mutable configuration map used by tests
     */
    static Map<String, String> baseConfig() {
        Map<String, String> config = new HashMap<>();
        config.put(CsfleDecryptConfig.AFTER_FIELD, "after");
        config.put(CsfleDecryptConfig.ENCRYPTED_FIELD, "messageValue");
        config.put(CsfleDecryptConfig.MONGODB_CONNECTION_STRING, "mongodb://localhost:27017");
        config.put(CsfleDecryptConfig.KEY_VAULT_NAMESPACE, "encryption.__keyVault");
        config.put(CsfleDecryptConfig.KMS_PROVIDER, "local");
        config.put(CsfleDecryptConfig.KMS_LOCAL_MASTER_KEY_BASE64, Base64.getEncoder().encodeToString(new byte[96]));
        return config;
    }

    /**
     * Builds a sample Debezium MongoDB {@code after} JSON document with encrypted message value.
     *
     * @return MongoDB document JSON containing canonical Extended JSON ciphertext
     */
    static String afterJsonWithEncryptedMessageValue() {
        return """
                {
                  "_id": "evt-123",
                  "topicName": "topic-a",
                  "messageKey": "order-456",
                  "messageValue": {"$binary": {"base64": "%s", "subType": "06"}},
                  "traceparent": "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
                  "__TypeId__": "com.example.OrderPaidEvent"
                }
                """.formatted(ENCRYPTED_BASE64);
    }

    /**
     * Builds a schemaful Debezium-style source record with an {@code after} field.
     *
     * @param afterJson MongoDB document JSON for the {@code after} field
     * @return schemaful source record
     */
    static SourceRecord structRecord(String afterJson) {
        Schema schema = SchemaBuilder.struct()
                .name("io.debezium.connector.mongodb.Envelope")
                .field("after", Schema.OPTIONAL_STRING_SCHEMA)
                .field("op", Schema.OPTIONAL_STRING_SCHEMA)
                .build();

        Struct value = new Struct(schema)
                .put("after", afterJson)
                .put("op", "c");

        return new SourceRecord(
                Map.of("server", "abganerovo"),
                Map.of("resumeToken", "token-1"),
                "abganerovo.def-device.msgv2_outbox",
                null,
                null,
                null,
                schema,
                value
        );
    }

    /**
     * Builds a schemaless Debezium-style source record with an {@code after} field.
     *
     * @param afterJson MongoDB document JSON for the {@code after} field
     * @return schemaless source record
     */
    static SourceRecord mapRecord(String afterJson) {
        Map<String, Object> value = new LinkedHashMap<>();
        value.put("after", afterJson);
        value.put("op", "c");

        return new SourceRecord(
                Map.of("server", "abganerovo"),
                Map.of("resumeToken", "token-1"),
                "abganerovo.def-device.msgv2_outbox",
                null,
                null,
                null,
                null,
                value
        );
    }

    /**
     * Fake decryptor that records calls and returns a configured plaintext value.
     */
    static final class FakeDecryptor implements BsonDecryptor {
        private final BsonValue decryptedValue;
        private BsonBinary lastEncryptedValue;
        private int decryptCalls;

        /**
         * Creates a fake decryptor that returns a BSON string.
         *
         * @param plaintextJsonString plaintext JSON string to return
         */
        FakeDecryptor(String plaintextJsonString) {
            this(new BsonString(plaintextJsonString));
        }

        /**
         * Creates a fake decryptor that returns an arbitrary BSON value.
         *
         * @param decryptedValue value to return from {@link #decrypt(BsonBinary)}
         */
        FakeDecryptor(BsonValue decryptedValue) {
            this.decryptedValue = decryptedValue;
        }

        /**
         * Records the encrypted value and returns the configured plaintext value.
         *
         * @param encryptedValue encrypted value passed by the class under test
         * @return configured decrypted value
         */
        @Override
        public BsonValue decrypt(BsonBinary encryptedValue) {
            this.decryptCalls++;
            this.lastEncryptedValue = encryptedValue;
            return decryptedValue;
        }

        /**
         * Returns the last encrypted value received by the fake decryptor.
         *
         * @return last encrypted value, or {@code null} if never called
         */
        BsonBinary lastEncryptedValue() {
            return lastEncryptedValue;
        }

        /**
         * Returns the number of decrypt calls received by the fake decryptor.
         *
         * @return decrypt invocation count
         */
        int decryptCalls() {
            return decryptCalls;
        }
    }
}
