package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.source.SourceRecord;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for reading and replacing Debezium MongoDB {@code after} fields.
 */
class DebeziumMongoRecordAccessorTest {
    private final DebeziumMongoRecordAccessor accessor = new DebeziumMongoRecordAccessor();

    /**
     * Verifies schemaful {@link Struct} values are copied and original records are not mutated.
     */
    @Test
    void readsAndReplacesStructAfterWithoutMutatingOriginal() {
        SourceRecord original = TestSupport.structRecord("{\"messageValue\":\"encrypted\"}");

        Optional<String> after = accessor.readAfter(original.value(), "after");
        SourceRecord transformed = accessor.replaceAfter(original, "after", "{\"messageValue\":\"decrypted\"}");

        assertTrue(after.isPresent());
        assertEquals("{\"messageValue\":\"encrypted\"}", after.get());
        assertSame(original.valueSchema(), transformed.valueSchema());
        assertEquals("{\"messageValue\":\"encrypted\"}", ((Struct) original.value()).getString("after"));
        assertEquals("{\"messageValue\":\"decrypted\"}", ((Struct) transformed.value()).getString("after"));
        assertEquals("c", ((Struct) transformed.value()).getString("op"));
    }

    /**
     * Verifies schemaless map values are copied and original records are not mutated.
     */
    @Test
    void readsAndReplacesMapAfterWithoutMutatingOriginal() {
        SourceRecord original = TestSupport.mapRecord("{\"messageValue\":\"encrypted\"}");

        Optional<String> after = accessor.readAfter(original.value(), "after");
        SourceRecord transformed = accessor.replaceAfter(original, "after", "{\"messageValue\":\"decrypted\"}");

        assertTrue(after.isPresent());
        assertEquals("{\"messageValue\":\"encrypted\"}", after.get());

        @SuppressWarnings("unchecked")
        Map<String, Object> originalValue = (Map<String, Object>) original.value();
        @SuppressWarnings("unchecked")
        Map<String, Object> transformedValue = (Map<String, Object>) transformed.value();

        assertEquals("{\"messageValue\":\"encrypted\"}", originalValue.get("after"));
        assertEquals("{\"messageValue\":\"decrypted\"}", transformedValue.get("after"));
        assertEquals("c", transformedValue.get("op"));
    }
}
