package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigException;
import org.apache.kafka.common.config.types.Password;
import org.apache.kafka.connect.transforms.util.SimpleConfig;

import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Parses, validates, and exposes configuration for {@link MongoCsfleDecryptMessageValue}.
 *
 * <p>Kafka Connect passes SMT configuration as a flat map of strings and typed values. This class
 * centralizes the {@link ConfigDef}, converts raw strings into enums, validates provider-specific
 * KMS settings, and exposes a small immutable API to the rest of the implementation.</p>
 */
public final class CsfleDecryptConfig {
    public static final String AFTER_FIELD = "after.field";
    public static final String ENCRYPTED_FIELD = "encrypted.field";
    public static final String MONGODB_CONNECTION_STRING = "mongodb.connection.string";
    public static final String KEY_VAULT_NAMESPACE = "key.vault.namespace";
    public static final String KMS_PROVIDER = "kms.provider";

    public static final String KMS_LOCAL_MASTER_KEY_BASE64 = "kms.local.master.key.base64";

    public static final String KMS_AWS_ACCESS_KEY_ID = "kms.aws.access.key.id";
    public static final String KMS_AWS_SECRET_ACCESS_KEY = "kms.aws.secret.access.key";
    public static final String KMS_AWS_SESSION_TOKEN = "kms.aws.session.token";

    public static final String KMS_AZURE_TENANT_ID = "kms.azure.tenant.id";
    public static final String KMS_AZURE_CLIENT_ID = "kms.azure.client.id";
    public static final String KMS_AZURE_CLIENT_SECRET = "kms.azure.client.secret";
    public static final String KMS_AZURE_IDENTITY_PLATFORM_ENDPOINT = "kms.azure.identity.platform.endpoint";

    public static final String KMS_GCP_EMAIL = "kms.gcp.email";
    public static final String KMS_GCP_PRIVATE_KEY = "kms.gcp.private.key";
    public static final String KMS_GCP_ENDPOINT = "kms.gcp.endpoint";

    public static final String KMS_KMIP_ENDPOINT = "kms.kmip.endpoint";

    public static final String MISSING_FIELD_BEHAVIOR = "missing.field.behavior";
    public static final String NULL_FIELD_BEHAVIOR = "null.field.behavior";
    public static final String DECRYPTED_VALUE_MODE = "decrypted.value.mode";

    /**
     * Kafka Connect configuration definition used for validation and UI/config descriptions.
     */
    public static final ConfigDef CONFIG_DEF = new ConfigDef()
            .define(AFTER_FIELD, ConfigDef.Type.STRING, "after", ConfigDef.Importance.HIGH,
                    "Debezium MongoDB envelope field that contains the full MongoDB document as JSON. Usually 'after'.")
            .define(ENCRYPTED_FIELD, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
                    "Top-level field inside the MongoDB outbox document that contains the CSFLE encrypted BSON Binary subtype 6 value.")
            .define(MONGODB_CONNECTION_STRING, ConfigDef.Type.PASSWORD, ConfigDef.Importance.HIGH,
                    "MongoDB connection string used by ClientEncryption to read the key vault collection.")
            .define(KEY_VAULT_NAMESPACE, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
                    "MongoDB key vault namespace, for example 'encryption.__keyVault'.")
            .define(KMS_PROVIDER, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
                    "KMS provider name. Supported values: local, aws, azure, gcp, kmip.")

            .define(KMS_LOCAL_MASTER_KEY_BASE64, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "Base64 encoded 96-byte local master key. Required when kms.provider=local.")

            .define(KMS_AWS_ACCESS_KEY_ID, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "AWS KMS access key id. Required when kms.provider=aws.")
            .define(KMS_AWS_SECRET_ACCESS_KEY, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "AWS KMS secret access key. Required when kms.provider=aws.")
            .define(KMS_AWS_SESSION_TOKEN, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.LOW,
                    "Optional AWS STS session token.")

            .define(KMS_AZURE_TENANT_ID, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "Azure tenant id. Required when kms.provider=azure.")
            .define(KMS_AZURE_CLIENT_ID, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "Azure client id. Required when kms.provider=azure.")
            .define(KMS_AZURE_CLIENT_SECRET, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "Azure client secret. Required when kms.provider=azure.")
            .define(KMS_AZURE_IDENTITY_PLATFORM_ENDPOINT, ConfigDef.Type.STRING, null, ConfigDef.Importance.LOW,
                    "Optional Azure identity platform endpoint.")

            .define(KMS_GCP_EMAIL, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "GCP service account email. Required when kms.provider=gcp.")
            .define(KMS_GCP_PRIVATE_KEY, ConfigDef.Type.PASSWORD, null, ConfigDef.Importance.MEDIUM,
                    "GCP service account private key. Required when kms.provider=gcp.")
            .define(KMS_GCP_ENDPOINT, ConfigDef.Type.STRING, null, ConfigDef.Importance.LOW,
                    "Optional GCP KMS endpoint.")

            .define(KMS_KMIP_ENDPOINT, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM,
                    "KMIP endpoint, for example 'kmip.example.com:5696'. Required when kms.provider=kmip.")

            .define(MISSING_FIELD_BEHAVIOR, ConfigDef.Type.STRING, "fail", ConfigDef.Importance.MEDIUM,
                    "Behavior when encrypted.field is missing. Supported values: fail, ignore.")
            .define(NULL_FIELD_BEHAVIOR, ConfigDef.Type.STRING, "fail", ConfigDef.Importance.MEDIUM,
                    "Behavior when encrypted.field is null. Supported values: fail, ignore.")
            .define(DECRYPTED_VALUE_MODE, ConfigDef.Type.STRING, "string", ConfigDef.Importance.MEDIUM,
                    "How to write the decrypted value back into the Debezium 'after' JSON. Supported values: string, preserve_bson. "
                            + "Use string with Debezium MongoEventRouter + collection.expand.json.payload=true + StringConverter.");

    /**
     * Behavior when the encrypted field is absent from the MongoDB outbox document.
     */
    public enum MissingFieldBehavior {
        /** Fail the connector task if the encrypted field is absent. */
        FAIL,
        /** Leave the record unchanged if the encrypted field is absent. */
        IGNORE;

        /**
         * Parses a configuration value into a missing-field behavior.
         *
         * @param raw raw configuration value
         * @param configName configuration key used in error messages
         * @return parsed behavior
         */
        static MissingFieldBehavior parse(String raw, String configName) {
            return parseEnum(MissingFieldBehavior.class, raw, configName);
        }
    }

    /**
     * Behavior when the encrypted field is present but null.
     */
    public enum NullFieldBehavior {
        /** Fail the connector task if the encrypted field is null. */
        FAIL,
        /** Leave the record unchanged if the encrypted field is null. */
        IGNORE;

        /**
         * Parses a configuration value into a null-field behavior.
         *
         * @param raw raw configuration value
         * @param configName configuration key used in error messages
         * @return parsed behavior
         */
        static NullFieldBehavior parse(String raw, String configName) {
            return parseEnum(NullFieldBehavior.class, raw, configName);
        }
    }

    /**
     * Controls how the decrypted BSON value is written back into the outbox document JSON.
     */
    public enum DecryptedValueMode {
        /** Write the decrypted value as a string field in the outbox document. */
        STRING,
        /** Preserve the decrypted BSON value's original BSON shape when writing it back. */
        PRESERVE_BSON;

        /**
         * Parses a configuration value into a decrypted-value output mode.
         *
         * @param raw raw configuration value
         * @param configName configuration key used in error messages
         * @return parsed mode
         */
        static DecryptedValueMode parse(String raw, String configName) {
            return parseEnum(DecryptedValueMode.class, raw, configName);
        }
    }

    private final String afterField;
    private final String encryptedField;
    private final String mongodbConnectionString;
    private final String keyVaultNamespace;
    private final String kmsProvider;
    private final MissingFieldBehavior missingFieldBehavior;
    private final NullFieldBehavior nullFieldBehavior;
    private final DecryptedValueMode decryptedValueMode;
    private final SimpleConfig simpleConfig;

    /**
     * Builds an immutable configuration object from Kafka Connect's typed config helper.
     *
     * @param simpleConfig parsed Kafka Connect config helper
     */
    private CsfleDecryptConfig(SimpleConfig simpleConfig) {
        this.simpleConfig = simpleConfig;
        this.afterField = simpleConfig.getString(AFTER_FIELD);
        this.encryptedField = simpleConfig.getString(ENCRYPTED_FIELD);
        this.mongodbConnectionString = requiredPassword(simpleConfig, MONGODB_CONNECTION_STRING);
        this.keyVaultNamespace = simpleConfig.getString(KEY_VAULT_NAMESPACE);
        this.kmsProvider = simpleConfig.getString(KMS_PROVIDER).toLowerCase(Locale.ROOT);
        this.missingFieldBehavior = MissingFieldBehavior.parse(simpleConfig.getString(MISSING_FIELD_BEHAVIOR), MISSING_FIELD_BEHAVIOR);
        this.nullFieldBehavior = NullFieldBehavior.parse(simpleConfig.getString(NULL_FIELD_BEHAVIOR), NULL_FIELD_BEHAVIOR);
        this.decryptedValueMode = DecryptedValueMode.parse(simpleConfig.getString(DECRYPTED_VALUE_MODE), DECRYPTED_VALUE_MODE);

        validateKmsProviderConfig();
    }

    /**
     * Parses and validates raw Kafka Connect SMT properties.
     *
     * @param props raw SMT properties passed by Kafka Connect
     * @return immutable parsed configuration
     */
    public static CsfleDecryptConfig from(Map<String, ?> props) {
        return new CsfleDecryptConfig(new SimpleConfig(CONFIG_DEF, props));
    }

    /**
     * Returns the Debezium envelope field that stores the MongoDB document JSON.
     *
     * @return envelope field name, normally {@code after}
     */
    public String afterField() {
        return afterField;
    }

    /**
     * Returns the top-level outbox document field that contains ciphertext.
     *
     * @return encrypted field name
     */
    public String encryptedField() {
        return encryptedField;
    }

    /**
     * Returns the MongoDB connection string used by the CSFLE key-vault client.
     *
     * @return MongoDB connection string
     */
    public String mongodbConnectionString() {
        return mongodbConnectionString;
    }

    /**
     * Returns the namespace of the MongoDB CSFLE key vault collection.
     *
     * @return key vault namespace such as {@code encryption.__keyVault}
     */
    public String keyVaultNamespace() {
        return keyVaultNamespace;
    }

    /**
     * Returns the configured KMS provider name.
     *
     * @return lower-case provider name
     */
    public String kmsProvider() {
        return kmsProvider;
    }

    /**
     * Returns behavior for missing encrypted fields.
     *
     * @return configured missing-field behavior
     */
    public MissingFieldBehavior missingFieldBehavior() {
        return missingFieldBehavior;
    }

    /**
     * Returns behavior for null encrypted fields.
     *
     * @return configured null-field behavior
     */
    public NullFieldBehavior nullFieldBehavior() {
        return nullFieldBehavior;
    }

    /**
     * Returns how decrypted BSON should be written back to the outbox document.
     *
     * @return configured decrypted-value output mode
     */
    public DecryptedValueMode decryptedValueMode() {
        return decryptedValueMode;
    }

    /**
     * Reads an optional password-style config value.
     *
     * @param name configuration key
     * @return optional password value, empty when absent or blank
     */
    public Optional<String> optionalPassword(String name) {
        Password password = simpleConfig.getPassword(name);
        if (password == null || password.value() == null || password.value().isBlank()) {
            return Optional.empty();
        }
        return Optional.of(password.value());
    }

    /**
     * Reads an optional string config value.
     *
     * @param name configuration key
     * @return optional string value, empty when absent or blank
     */
    public Optional<String> optionalString(String name) {
        String value = simpleConfig.getString(name);
        if (value == null || value.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(value);
    }

    /**
     * Reads a required password-style config value.
     *
     * @param name configuration key
     * @return non-blank password value
     */
    public String requiredPassword(String name) {
        return requiredPassword(simpleConfig, name);
    }

    /**
     * Reads a required string config value.
     *
     * @param name configuration key
     * @return non-blank string value
     */
    public String requiredString(String name) {
        String value = simpleConfig.getString(name);
        if (value == null || value.isBlank()) {
            throw new ConfigException("Missing required config: " + name);
        }
        return value;
    }

    /**
     * Validates provider-specific KMS configuration after the provider name is parsed.
     */
    private void validateKmsProviderConfig() {
        switch (kmsProvider) {
            case "local" -> requiredPassword(KMS_LOCAL_MASTER_KEY_BASE64);
            case "aws" -> {
                requiredPassword(KMS_AWS_ACCESS_KEY_ID);
                requiredPassword(KMS_AWS_SECRET_ACCESS_KEY);
            }
            case "azure" -> {
                requiredPassword(KMS_AZURE_TENANT_ID);
                requiredPassword(KMS_AZURE_CLIENT_ID);
                requiredPassword(KMS_AZURE_CLIENT_SECRET);
            }
            case "gcp" -> {
                requiredPassword(KMS_GCP_EMAIL);
                requiredPassword(KMS_GCP_PRIVATE_KEY);
            }
            case "kmip" -> requiredString(KMS_KMIP_ENDPOINT);
            default -> throw new ConfigException(KMS_PROVIDER, kmsProvider, "Supported values: local, aws, azure, gcp, kmip");
        }
    }

    /**
     * Reads and validates a required password value from the supplied config helper.
     *
     * @param simpleConfig parsed config helper
     * @param name configuration key
     * @return non-blank password value
     */
    private static String requiredPassword(SimpleConfig simpleConfig, String name) {
        Password password = simpleConfig.getPassword(name);
        if (password == null || password.value() == null || password.value().isBlank()) {
            throw new ConfigException("Missing required config: " + name);
        }
        return password.value();
    }

    /**
     * Parses an enum from user-friendly config text.
     *
     * <p>The parser accepts lower-case values and hyphenated values by converting input to upper
     * case and replacing hyphens with underscores before calling {@link Enum#valueOf(Class, String)}.</p>
     *
     * @param enumType enum type to parse
     * @param raw raw configuration value
     * @param configName configuration key used in error messages
     * @param <E> enum type
     * @return parsed enum value
     */
    private static <E extends Enum<E>> E parseEnum(Class<E> enumType, String raw, String configName) {
        if (raw == null || raw.isBlank()) {
            throw new ConfigException("Missing required config: " + configName);
        }
        String normalized = raw.trim().toUpperCase(Locale.ROOT).replace('-', '_');
        try {
            return Enum.valueOf(enumType, normalized);
        } catch (IllegalArgumentException e) {
            throw new ConfigException(configName, raw, "Unsupported value");
        }
    }
}
