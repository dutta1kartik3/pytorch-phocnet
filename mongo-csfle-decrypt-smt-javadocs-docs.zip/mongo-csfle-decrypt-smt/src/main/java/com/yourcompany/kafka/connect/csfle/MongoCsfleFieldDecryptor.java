package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.errors.ConnectException;
import org.bson.BsonBinary;
import org.bson.BsonDocument;
import org.bson.BsonNull;
import org.bson.BsonValue;
import org.bson.json.JsonMode;
import org.bson.json.JsonWriterSettings;

import java.util.Objects;

/**
 * Decrypts one top-level encrypted field inside Debezium's MongoDB {@code after} JSON document.
 *
 * <p>This class is where the record payload is actually changed. It parses the MongoDB document
 * JSON, extracts the configured encrypted field, decrypts it, formats the decrypted value, and
 * returns a new JSON string containing the modified field.</p>
 */
public final class MongoCsfleFieldDecryptor {
    private static final JsonWriterSettings JSON_SETTINGS = JsonWriterSettings.builder()
            .outputMode(JsonMode.RELAXED)
            .build();

    private final CsfleDecryptConfig config;
    private final BsonDecryptor decryptor;
    private final EncryptedBinaryExtractor encryptedBinaryExtractor;
    private final DecryptedValueFormatter decryptedValueFormatter;

    /**
     * Creates a field decryptor with all parsing, decrypting, and formatting collaborators.
     *
     * @param config parsed SMT configuration
     * @param decryptor CSFLE decryptor
     * @param encryptedBinaryExtractor extractor for subtype-6 ciphertext
     * @param decryptedValueFormatter formatter for decrypted BSON values
     */
    public MongoCsfleFieldDecryptor(
            CsfleDecryptConfig config,
            BsonDecryptor decryptor,
            EncryptedBinaryExtractor encryptedBinaryExtractor,
            DecryptedValueFormatter decryptedValueFormatter
    ) {
        this.config = Objects.requireNonNull(config, "config");
        this.decryptor = Objects.requireNonNull(decryptor, "decryptor");
        this.encryptedBinaryExtractor = Objects.requireNonNull(encryptedBinaryExtractor, "encryptedBinaryExtractor");
        this.decryptedValueFormatter = Objects.requireNonNull(decryptedValueFormatter, "decryptedValueFormatter");
    }

    /**
     * Decrypts the configured field inside an {@code after} JSON document.
     *
     * @param afterJson Debezium MongoDB {@code after} field containing the full document JSON
     * @return JSON document with the configured encrypted field replaced by a decrypted value
     */
    public String decryptFieldInAfterJson(String afterJson) {
        if (afterJson == null || afterJson.isBlank()) {
            return afterJson;
        }

        BsonDocument document;
        try {
            document = BsonDocument.parse(afterJson);
        } catch (Exception e) {
            throw new ConnectException("Failed to parse Debezium MongoDB after JSON", e);
        }

        String fieldName = config.encryptedField();
        if (!document.containsKey(fieldName)) {
            if (config.missingFieldBehavior() == CsfleDecryptConfig.MissingFieldBehavior.IGNORE) {
                return afterJson;
            }
            throw new ConnectException("Encrypted field '" + fieldName + "' is missing from outbox document");
        }

        BsonValue encryptedValue = document.get(fieldName);
        if (encryptedValue == null || encryptedValue instanceof BsonNull || encryptedValue.isNull()) {
            if (config.nullFieldBehavior() == CsfleDecryptConfig.NullFieldBehavior.IGNORE) {
                return afterJson;
            }
            throw new ConnectException("Encrypted field '" + fieldName + "' is null in outbox document");
        }

        BsonBinary encryptedBinary = encryptedBinaryExtractor.extract(encryptedValue, fieldName);
        BsonValue decryptedValue;
        try {
            decryptedValue = decryptor.decrypt(encryptedBinary);
        } catch (Exception e) {
            throw new ConnectException("MongoDB CSFLE decryption failed for field '" + fieldName + "'", e);
        }

        BsonValue formattedValue = decryptedValueFormatter.format(decryptedValue, config.decryptedValueMode());
        document.put(fieldName, formattedValue);
        return document.toJson(JSON_SETTINGS);
    }
}
