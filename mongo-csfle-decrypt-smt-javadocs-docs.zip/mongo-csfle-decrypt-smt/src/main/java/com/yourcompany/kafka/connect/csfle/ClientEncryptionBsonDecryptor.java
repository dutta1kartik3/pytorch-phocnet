package com.yourcompany.kafka.connect.csfle;

import com.mongodb.client.vault.ClientEncryption;
import org.bson.BsonBinary;
import org.bson.BsonValue;

import java.util.Objects;

/**
 * Production {@link BsonDecryptor} backed by MongoDB Java driver's {@link ClientEncryption}.
 *
 * <p>This class is deliberately tiny: it adapts the MongoDB driver's API into the internal
 * {@link BsonDecryptor} interface used by the SMT.</p>
 */
public final class ClientEncryptionBsonDecryptor implements BsonDecryptor {
    private final ClientEncryption clientEncryption;

    /**
     * Creates a decryptor that delegates to the supplied MongoDB {@link ClientEncryption} object.
     *
     * @param clientEncryption configured MongoDB client-side encryption object
     */
    public ClientEncryptionBsonDecryptor(ClientEncryption clientEncryption) {
        this.clientEncryption = Objects.requireNonNull(clientEncryption, "clientEncryption");
    }

    /**
     * Decrypts the supplied subtype-6 encrypted BSON binary value.
     *
     * @param encryptedValue encrypted BSON binary value
     * @return decrypted BSON value
     */
    @Override
    public BsonValue decrypt(BsonBinary encryptedValue) {
        return clientEncryption.decrypt(encryptedValue);
    }

    /**
     * Closes the underlying {@link ClientEncryption} instance.
     */
    @Override
    public void close() {
        clientEncryption.close();
    }
}
