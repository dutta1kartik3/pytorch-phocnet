package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.transforms.Transformation;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Kafka Connect Single Message Transform that decrypts a CSFLE encrypted outbox payload field.
 *
 * <p>The transform is designed for Debezium MongoDB source records. It reads the Debezium
 * {@code after} JSON document, decrypts the configured field inside that document, and returns a
 * new record with the updated {@code after} JSON. It should be placed before Debezium's MongoDB
 * {@code MongoEventRouter} outbox SMT so the outbox router sees a plaintext payload field.</p>
 *
 * @param <R> Kafka Connect record type handled by the transform
 */
public class MongoCsfleDecryptMessageValue<R extends ConnectRecord<R>> implements Transformation<R> {
    private final ClientEncryptionFactory clientEncryptionFactory;
    private final DebeziumMongoRecordAccessor recordAccessor;
    private final EncryptedBinaryExtractor encryptedBinaryExtractor;
    private final DecryptedValueFormatter decryptedValueFormatter;

    private BsonDecryptor decryptor;
    private boolean decryptorInjectedForTests;
    private CsfleDecryptConfig config;
    private MongoCsfleFieldDecryptor fieldDecryptor;

    /**
     * Creates the production SMT with default collaborators.
     *
     * <p>Kafka Connect uses this public no-argument constructor when loading the transform from the
     * plugin path.</p>
     */
    public MongoCsfleDecryptMessageValue() {
        this(new ClientEncryptionFactory(), new DebeziumMongoRecordAccessor(), new EncryptedBinaryExtractor(), new DecryptedValueFormatter());
    }

    /**
     * Creates the SMT with an injected decryptor for tests.
     *
     * @param decryptor fake or custom decryptor used by tests
     */
    MongoCsfleDecryptMessageValue(BsonDecryptor decryptor) {
        this();
        this.decryptor = Objects.requireNonNull(decryptor, "decryptor");
        this.decryptorInjectedForTests = true;
    }

    /**
     * Creates the SMT with explicit collaborators.
     *
     * @param clientEncryptionFactory factory for production CSFLE decryptors
     * @param recordAccessor accessor for Debezium MongoDB record envelopes
     * @param encryptedBinaryExtractor extractor for encrypted BSON binary values
     * @param decryptedValueFormatter formatter for decrypted BSON values
     */
    MongoCsfleDecryptMessageValue(
            ClientEncryptionFactory clientEncryptionFactory,
            DebeziumMongoRecordAccessor recordAccessor,
            EncryptedBinaryExtractor encryptedBinaryExtractor,
            DecryptedValueFormatter decryptedValueFormatter
    ) {
        this.clientEncryptionFactory = Objects.requireNonNull(clientEncryptionFactory, "clientEncryptionFactory");
        this.recordAccessor = Objects.requireNonNull(recordAccessor, "recordAccessor");
        this.encryptedBinaryExtractor = Objects.requireNonNull(encryptedBinaryExtractor, "encryptedBinaryExtractor");
        this.decryptedValueFormatter = Objects.requireNonNull(decryptedValueFormatter, "decryptedValueFormatter");
    }

    /**
     * Configures the SMT and initializes the MongoDB CSFLE decryptor.
     *
     * @param props transform configuration supplied by Kafka Connect
     */
    @Override
    public void configure(Map<String, ?> props) {
        this.config = CsfleDecryptConfig.from(props);
        if (this.decryptor == null) {
            this.decryptor = clientEncryptionFactory.create(config);
        }
        this.fieldDecryptor = new MongoCsfleFieldDecryptor(config, decryptor, encryptedBinaryExtractor, decryptedValueFormatter);
    }

    /**
     * Applies the transform to one Kafka Connect record.
     *
     * <p>Records with no value, no {@code after} field, or a blank {@code after} field are returned
     * unchanged. Records with decryptable outbox JSON are copied with a modified {@code after}
     * field. The original record value is never mutated.</p>
     *
     * @param record source record emitted by Debezium
     * @return original record when no change is needed, or a new record with decrypted {@code after}
     */
    @Override
    public R apply(R record) {
        if (record == null || record.value() == null) {
            return record;
        }

        Optional<String> after = recordAccessor.readAfter(record.value(), config.afterField());
        if (after.isEmpty()) {
            return record;
        }

        String decryptedAfter = fieldDecryptor.decryptFieldInAfterJson(after.get());
        if (decryptedAfter.equals(after.get())) {
            return record;
        }

        return recordAccessor.replaceAfter(record, config.afterField(), decryptedAfter);
    }

    /**
     * Returns Kafka Connect's configuration definition for this SMT.
     *
     * @return configuration definition used for validation and documentation
     */
    @Override
    public ConfigDef config() {
        return CsfleDecryptConfig.CONFIG_DEF;
    }

    /**
     * Closes resources owned by this SMT instance.
     *
     * <p>Kafka Connect calls this when the task is stopped or reconfigured. Test-injected
     * decryptors are not closed by this class.</p>
     */
    @Override
    public void close() {
        if (decryptor != null && !decryptorInjectedForTests) {
            decryptor.close();
        }
    }
}
