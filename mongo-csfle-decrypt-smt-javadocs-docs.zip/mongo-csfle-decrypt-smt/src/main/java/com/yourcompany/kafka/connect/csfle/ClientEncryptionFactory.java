package com.yourcompany.kafka.connect.csfle;

import com.mongodb.ClientEncryptionSettings;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.vault.ClientEncryptions;

import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Factory that builds the production MongoDB CSFLE decryptor from SMT configuration.
 *
 * <p>The factory owns all MongoDB-specific setup: key-vault connection settings, key-vault
 * namespace, and KMS provider maps. Keeping this outside the SMT entry point makes the transform
 * easier to unit test and keeps configuration parsing separate from dependency construction.</p>
 */
public final class ClientEncryptionFactory {

    /**
     * Creates a {@link BsonDecryptor} backed by MongoDB's {@code ClientEncryption} API.
     *
     * @param config parsed SMT configuration
     * @return production decryptor for the configured key vault and KMS provider
     */
    public BsonDecryptor create(CsfleDecryptConfig config) {
        MongoClientSettings keyVaultClientSettings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(config.mongodbConnectionString()))
                .build();

        ClientEncryptionSettings clientEncryptionSettings = ClientEncryptionSettings.builder()
                .keyVaultMongoClientSettings(keyVaultClientSettings)
                .keyVaultNamespace(config.keyVaultNamespace())
                .kmsProviders(kmsProviders(config))
                .build();

        return new ClientEncryptionBsonDecryptor(ClientEncryptions.create(clientEncryptionSettings));
    }

    /**
     * Builds the MongoDB driver KMS provider map for the configured provider name.
     *
     * @param config parsed SMT configuration
     * @return KMS provider map expected by {@code ClientEncryptionSettings}
     */
    private Map<String, Map<String, Object>> kmsProviders(CsfleDecryptConfig config) {
        return switch (config.kmsProvider()) {
            case "local" -> local(config);
            case "aws" -> aws(config);
            case "azure" -> azure(config);
            case "gcp" -> gcp(config);
            case "kmip" -> kmip(config);
            default -> throw new IllegalArgumentException("Unsupported KMS provider: " + config.kmsProvider());
        };
    }

    /**
     * Builds the KMS provider map for MongoDB's local KMS provider.
     *
     * @param config parsed SMT configuration
     * @return singleton KMS provider map for {@code local}
     */
    private Map<String, Map<String, Object>> local(CsfleDecryptConfig config) {
        byte[] masterKey = Base64.getDecoder().decode(config.requiredPassword(CsfleDecryptConfig.KMS_LOCAL_MASTER_KEY_BASE64));
        return Map.of("local", Map.of("key", masterKey));
    }

    /**
     * Builds the KMS provider map for AWS KMS.
     *
     * @param config parsed SMT configuration
     * @return singleton KMS provider map for {@code aws}
     */
    private Map<String, Map<String, Object>> aws(CsfleDecryptConfig config) {
        Map<String, Object> aws = new LinkedHashMap<>();
        aws.put("accessKeyId", config.requiredPassword(CsfleDecryptConfig.KMS_AWS_ACCESS_KEY_ID));
        aws.put("secretAccessKey", config.requiredPassword(CsfleDecryptConfig.KMS_AWS_SECRET_ACCESS_KEY));
        config.optionalPassword(CsfleDecryptConfig.KMS_AWS_SESSION_TOKEN).ifPresent(token -> aws.put("sessionToken", token));
        return Map.of("aws", aws);
    }

    /**
     * Builds the KMS provider map for Azure Key Vault.
     *
     * @param config parsed SMT configuration
     * @return singleton KMS provider map for {@code azure}
     */
    private Map<String, Map<String, Object>> azure(CsfleDecryptConfig config) {
        Map<String, Object> azure = new LinkedHashMap<>();
        azure.put("tenantId", config.requiredPassword(CsfleDecryptConfig.KMS_AZURE_TENANT_ID));
        azure.put("clientId", config.requiredPassword(CsfleDecryptConfig.KMS_AZURE_CLIENT_ID));
        azure.put("clientSecret", config.requiredPassword(CsfleDecryptConfig.KMS_AZURE_CLIENT_SECRET));
        config.optionalString(CsfleDecryptConfig.KMS_AZURE_IDENTITY_PLATFORM_ENDPOINT)
                .ifPresent(endpoint -> azure.put("identityPlatformEndpoint", endpoint));
        return Map.of("azure", azure);
    }

    /**
     * Builds the KMS provider map for Google Cloud KMS.
     *
     * @param config parsed SMT configuration
     * @return singleton KMS provider map for {@code gcp}
     */
    private Map<String, Map<String, Object>> gcp(CsfleDecryptConfig config) {
        Map<String, Object> gcp = new LinkedHashMap<>();
        gcp.put("email", config.requiredPassword(CsfleDecryptConfig.KMS_GCP_EMAIL));
        gcp.put("privateKey", config.requiredPassword(CsfleDecryptConfig.KMS_GCP_PRIVATE_KEY));
        config.optionalString(CsfleDecryptConfig.KMS_GCP_ENDPOINT).ifPresent(endpoint -> gcp.put("endpoint", endpoint));
        return Map.of("gcp", gcp);
    }

    /**
     * Builds the KMS provider map for a KMIP endpoint.
     *
     * @param config parsed SMT configuration
     * @return singleton KMS provider map for {@code kmip}
     */
    private Map<String, Map<String, Object>> kmip(CsfleDecryptConfig config) {
        return Map.of("kmip", Map.of("endpoint", config.requiredString(CsfleDecryptConfig.KMS_KMIP_ENDPOINT)));
    }
}
