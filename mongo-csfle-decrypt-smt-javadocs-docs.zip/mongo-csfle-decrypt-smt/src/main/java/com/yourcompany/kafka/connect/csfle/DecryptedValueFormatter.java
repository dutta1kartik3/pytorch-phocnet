package com.yourcompany.kafka.connect.csfle;

import org.bson.BsonDocument;
import org.bson.BsonNull;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.json.JsonMode;
import org.bson.json.JsonWriterSettings;

/**
 * Converts decrypted BSON into the value written back to the MongoDB outbox document JSON.
 *
 * <p>The main production mode is {@link CsfleDecryptConfig.DecryptedValueMode#STRING}, which is
 * intended for an outbox value field containing JSON text. In that mode, downstream Debezium
 * {@code MongoEventRouter} can expand the JSON payload and write it with {@code StringConverter}.</p>
 */
public final class DecryptedValueFormatter {
    private static final JsonWriterSettings JSON_SETTINGS = JsonWriterSettings.builder()
            .outputMode(JsonMode.RELAXED)
            .build();

    /**
     * Formats a decrypted BSON value according to the configured output mode.
     *
     * @param decryptedValue value returned by MongoDB client-side encryption
     * @param mode formatting mode selected by SMT configuration
     * @return BSON value to place into the updated outbox document JSON
     */
    public BsonValue format(BsonValue decryptedValue, CsfleDecryptConfig.DecryptedValueMode mode) {
        if (decryptedValue == null || decryptedValue.isNull()) {
            return BsonNull.VALUE;
        }
        return switch (mode) {
            case PRESERVE_BSON -> decryptedValue;
            case STRING -> new BsonString(toStringPayload(decryptedValue));
        };
    }

    /**
     * Converts a decrypted BSON value into the string payload expected by the outbox SMT.
     *
     * @param decryptedValue decrypted BSON value
     * @return string payload to write into the outbox field
     */
    private String toStringPayload(BsonValue decryptedValue) {
        if (decryptedValue.isString()) {
            // For the outbox use case, this is normally already JSON text, e.g. {"orderId":"123"}.
            return decryptedValue.asString().getValue();
        }
        return bsonValueToJson(decryptedValue);
    }

    /**
     * Serializes any BSON value into relaxed JSON.
     *
     * <p>{@link BsonDocument} has a direct {@code toJson()} method, but scalar and array values do
     * not expose a consistent direct JSON method across all driver versions. Wrapping the value in
     * a temporary document allows the BSON writer to serialize it, after which the wrapper is
     * removed.</p>
     *
     * @param value BSON value to serialize
     * @return relaxed JSON representation of the value
     */
    private String bsonValueToJson(BsonValue value) {
        String wrapperJson = new BsonDocument("v", value).toJson(JSON_SETTINGS);
        int colonIndex = wrapperJson.indexOf(':');
        if (colonIndex < 0 || !wrapperJson.endsWith("}")) {
            throw new IllegalStateException("Unexpected BSON wrapper JSON: " + wrapperJson);
        }
        return wrapperJson.substring(colonIndex + 1, wrapperJson.length() - 1).trim();
    }
}
