/**
 * Kafka Connect SMT components for decrypting MongoDB CSFLE encrypted fields in Debezium MongoDB
 * source records before the Debezium MongoDB outbox router runs.
 */
package com.yourcompany.kafka.connect.csfle;
