package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.data.Field;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.errors.ConnectException;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Reads and replaces Debezium MongoDB envelope fields without mutating the original record.
 *
 * <p>Debezium MongoDB source records can be represented either as schemaful {@link Struct}
 * values or as schemaless {@link Map} values, depending on converter and worker settings. This
 * accessor supports both shapes and always creates a replacement object when updating the
 * {@code after} field.</p>
 */
public final class DebeziumMongoRecordAccessor {

    /**
     * Reads the Debezium MongoDB {@code after} field from a schemaful or schemaless record value.
     *
     * @param recordValue Kafka Connect record value, usually a {@link Struct} or {@link Map}
     * @param afterField configured field name that stores the MongoDB document JSON
     * @return non-blank {@code after} JSON when present
     */
    public Optional<String> readAfter(Object recordValue, String afterField) {
        if (recordValue == null) {
            return Optional.empty();
        }

        if (recordValue instanceof Struct struct) {
            if (struct.schema() == null || struct.schema().field(afterField) == null) {
                return Optional.empty();
            }
            Object value = struct.get(afterField);
            return stringValue(value, afterField);
        }

        if (recordValue instanceof Map<?, ?> map) {
            Object value = map.get(afterField);
            return stringValue(value, afterField);
        }

        throw new ConnectException("Unsupported Debezium MongoDB record value type: " + recordValue.getClass().getName());
    }

    /**
     * Returns a new Kafka Connect record whose {@code after} field has been replaced.
     *
     * <p>The input record and its value object are left unchanged. Kafka Connect transformations
     * should avoid mutating the original record because other transforms or framework code may
     * still hold references to it.</p>
     *
     * @param record source record to copy
     * @param afterField configured field name that stores the MongoDB document JSON
     * @param newAfter replacement {@code after} JSON
     * @param <R> concrete Connect record type
     * @return new record containing a copied value with the replacement {@code after} field
     */
    public <R extends ConnectRecord<R>> R replaceAfter(R record, String afterField, String newAfter) {
        Object recordValue = record.value();
        if (recordValue instanceof Struct struct) {
            Struct replacement = copyStructWithAfter(struct, afterField, newAfter);
            return record.newRecord(
                    record.topic(),
                    record.kafkaPartition(),
                    record.keySchema(),
                    record.key(),
                    record.valueSchema(),
                    replacement,
                    record.timestamp(),
                    record.headers()
            );
        }

        if (recordValue instanceof Map<?, ?> map) {
            Map<String, Object> replacement = copyMapWithAfter(map, afterField, newAfter);
            return record.newRecord(
                    record.topic(),
                    record.kafkaPartition(),
                    record.keySchema(),
                    record.key(),
                    record.valueSchema(),
                    replacement,
                    record.timestamp(),
                    record.headers()
            );
        }

        throw new ConnectException("Unsupported Debezium MongoDB record value type: " + recordValue.getClass().getName());
    }

    /**
     * Converts a raw field value into a non-blank string optional.
     *
     * @param value raw field value
     * @param afterField field name used in error messages
     * @return non-blank string value when present
     */
    private Optional<String> stringValue(Object value, String afterField) {
        if (value == null) {
            return Optional.empty();
        }
        if (!(value instanceof String stringValue)) {
            throw new ConnectException("Expected Debezium MongoDB envelope field '" + afterField + "' to be a string but found " + value.getClass().getName());
        }
        if (stringValue.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(stringValue);
    }

    /**
     * Copies a schemaful Debezium value and replaces one field.
     *
     * @param original original Debezium value struct
     * @param afterField field to replace
     * @param newAfter replacement field value
     * @return copied struct with the replacement value
     */
    private Struct copyStructWithAfter(Struct original, String afterField, String newAfter) {
        if (original.schema().field(afterField) == null) {
            throw new ConnectException("Schema does not contain after field: " + afterField);
        }

        Struct copy = new Struct(original.schema());
        for (Field field : original.schema().fields()) {
            Object value = original.get(field.name());
            copy.put(field.name(), value);
        }
        copy.put(afterField, newAfter);
        return copy;
    }

    /**
     * Copies a schemaless Debezium value map and replaces one field.
     *
     * @param original original Debezium value map
     * @param afterField field to replace
     * @param newAfter replacement field value
     * @return copied map with the replacement value
     */
    private Map<String, Object> copyMapWithAfter(Map<?, ?> original, String afterField, String newAfter) {
        Map<String, Object> copy = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : original.entrySet()) {
            Object rawKey = entry.getKey();
            if (!(rawKey instanceof String key)) {
                throw new ConnectException("Schemaless record value map contains non-string key: " + rawKey);
            }
            copy.put(key, entry.getValue());
        }
        copy.put(afterField, newAfter);
        return copy;
    }
}
