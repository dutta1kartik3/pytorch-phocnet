package com.yourcompany.kafka.connect.csfle;

import org.apache.kafka.connect.errors.ConnectException;
import org.bson.BsonBinary;
import org.bson.BsonDocument;
import org.bson.BsonString;
import org.bson.BsonValue;

import java.util.Base64;

/**
 * Extracts MongoDB CSFLE ciphertext from Debezium's Extended JSON representation.
 *
 * <p>MongoDB CSFLE ciphertext is a BSON Binary value with subtype {@code 6}. Debezium's MongoDB
 * connector usually represents that value in the {@code after} JSON using Extended JSON, for
 * example {@code {"$binary": {"base64": "...", "subType": "06"}}}. This class accepts both
 * already-parsed {@link BsonBinary} values and defensive Extended JSON document shapes.</p>
 */
public final class EncryptedBinaryExtractor {
    private static final int CSFLE_ENCRYPTED_BINARY_SUBTYPE = 6;

    /**
     * Extracts and validates a CSFLE encrypted BSON binary value.
     *
     * @param value parsed BSON value from the configured encrypted field
     * @param fieldName field name used for error messages
     * @return BSON binary value with subtype {@code 6}
     */
    public BsonBinary extract(BsonValue value, String fieldName) {
        BsonBinary binary = toBsonBinary(value, fieldName);
        int subtype = Byte.toUnsignedInt(binary.getType());
        if (subtype != CSFLE_ENCRYPTED_BINARY_SUBTYPE) {
            throw new ConnectException("Expected MongoDB CSFLE encrypted BSON Binary subtype 6 for field '"
                    + fieldName + "' but found subtype " + subtype);
        }
        return binary;
    }

    /**
     * Converts a parsed BSON value into a {@link BsonBinary} without validating subtype.
     *
     * @param value parsed BSON value
     * @param fieldName field name used for error messages
     * @return BSON binary value
     */
    private BsonBinary toBsonBinary(BsonValue value, String fieldName) {
        if (value == null || value.isNull()) {
            throw new ConnectException("Encrypted field '" + fieldName + "' is null");
        }
        if (value.isBinary()) {
            return value.asBinary();
        }

        // Defensive fallback for cases where a parser leaves Extended JSON as a normal document.
        if (value.isDocument()) {
            BsonDocument document = value.asDocument();
            BsonValue binaryValue = document.get("$binary");
            if (binaryValue != null && binaryValue.isDocument()) {
                BsonDocument binaryDocument = binaryValue.asDocument();
                BsonValue base64Value = binaryDocument.get("base64");
                BsonValue subTypeValue = binaryDocument.get("subType");
                if (base64Value instanceof BsonString && subTypeValue instanceof BsonString) {
                    byte[] bytes = Base64.getDecoder().decode(base64Value.asString().getValue());
                    byte subtype = (byte) Integer.parseInt(subTypeValue.asString().getValue(), 16);
                    return new BsonBinary(subtype, bytes);
                }
            }
        }

        throw new ConnectException("Encrypted field '" + fieldName
                + "' must be BSON Binary subtype 6 or canonical Extended JSON $binary. Actual value: " + value);
    }
}
