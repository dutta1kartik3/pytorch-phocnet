package com.yourcompany.kafka.connect.csfle;

import org.bson.BsonBinary;
import org.bson.BsonValue;

/**
 * Abstraction for decrypting a MongoDB CSFLE encrypted BSON value.
 *
 * <p>The production implementation delegates to MongoDB Java driver's
 * {@code ClientEncryption}. Tests use a fake implementation so that unit tests do not need a
 * running MongoDB key vault or KMS provider.</p>
 */
public interface BsonDecryptor extends AutoCloseable {

    /**
     * Decrypts a MongoDB CSFLE encrypted binary value.
     *
     * @param encryptedValue encrypted BSON binary value, expected to be subtype {@code 6}
     * @return decrypted BSON value returned by MongoDB client-side encryption
     */
    BsonValue decrypt(BsonBinary encryptedValue);

    /**
     * Releases any resources held by the decryptor.
     *
     * <p>The default is a no-op for fake/test implementations. Production implementations should
     * override this when they own closeable resources.</p>
     */
    @Override
    default void close() {
        // no-op for tests/fakes
    }
}
